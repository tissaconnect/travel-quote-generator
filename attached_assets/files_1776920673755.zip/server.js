const express = require('express');
const app = express();

app.use(express.json());
app.use(express.static('public'));

// Proxy endpoint — keeps your API key safe on the server
app.post('/api/parse-quotes', async (req, res) => {
  const { rawText, tripDetails } = req.body;

  const prompt = `You are a travel quote parser. Extract hotel options from this raw travel quote text and return ONLY valid JSON, no markdown, no explanation.

Trip Details:
- Destination: ${tripDetails.destination}
- Dates: ${tripDetails.dates}
- Adults: ${tripDetails.adults}
- Nights: ${tripDetails.nights}

Raw Quote Text:
${rawText}

Return this exact JSON structure:
{
  "hotels": [
    {
      "name": "Hotel name",
      "stars": 4,
      "category": "Budget-Friendly / Best Value / Mid-Range / Luxury",
      "totalPrice": "$2,058",
      "perPersonPrice": "$1,029",
      "refundableBy": "Dec 7",
      "highlights": ["highlight 1", "highlight 2", "highlight 3"],
      "vibe": "One sentence description of the vibe/energy",
      "pros": ["pro 1", "pro 2", "pro 3"],
      "advisorPick": false
    }
  ],
  "advisorNote": "Advisor's personal recommendation summary if present"
}

Extract all hotels mentioned. Set advisorPick to true for the one the advisor recommends most strongly.`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 2000,
        messages: [{ role: 'user', content: prompt }]
      })
    });

    const data = await response.json();
    const text = data.content[0].text.trim();
    const jsonStart = text.indexOf('{');
    const jsonEnd = text.lastIndexOf('}') + 1;
    const parsed = JSON.parse(text.slice(jsonStart, jsonEnd));
    res.json(parsed);
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: 'Failed to parse quotes. Check your API key.' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Running on port ${PORT}`));
